$Id: readme.txt 13 2004-08-05 20:26:49Z dietsche $

Lionel Debroux sent this source code to me. It is very complete, and contain every known rom call and many undocumented rom calls which are noted by the * that precedes them.

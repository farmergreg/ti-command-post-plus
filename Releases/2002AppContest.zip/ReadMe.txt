*****For Best Viewing, use Word Wrap in Notepad*****

There are a few issues regarding Command Post that the Judges should be aware of.

The simulator included with the TI-Flash Studio SDK for the 68k calculators is not perfect by any means.
If Command Post is judged using the Simulator, please be aware of the following issues:
1. It may be possible to view 'read protected' memory areas.
2. It may be possible to write to 'write protected' memory areas.
3. The Protected Memory Violation (Auto Interrupt 7) is not emulated, and you can therefore write to memory addresses below 0x150 without causing a 'Protected Memory Violation' error.
4. The Anti-Crash Protection found in Command Post will not work in the simulator.
5. There may be other Simulator Shortcomings that I have not noticed while using Command Post with the simulator.

If Command Post is tested on a REAL calculator, the ErrorSim utility found in the errorsim folder can simulate many errors that Command Post handles with its anti-crash protection mechanism.

I have provided documentation in both .pdf, and .doc formats for your convenience. Additionally, I have provided the source code for Command Post so that there will be no questions regarding Command Post and the Rules for this contest.

Please read the Getting Started Section, and Shortcut Keys as a minimum. These two sections outline the basic features and principles needed to operate Command Post efficiently.

The tools that are a part of Command Post have a unique and powerful nature, I encourage you to play with them and learn about the calculator. But, Please be careful! Part of the power of Command Post comes from its open-ended design, and as a result, Command Post will allow you to do things that may cause your calculator to become unstable and/or crash. For instance, viewing the memory at 0x4200 is interesting, but changing the surrounding memory areas could cause your calculator to crash because that area of memory contains the user, and supervisor stacks!

Finally, Command Post is a fairly large project, and as such, likely contains a few bugs. I am not aware of any bugs in the version of Command Post which I have submitted to the App Contest. If any bugs are found, please contact me either directly, or indirectly after the contest judging and results are finalized.

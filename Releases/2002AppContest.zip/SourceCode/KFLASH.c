/**************************************************
***	Project Title: Command Post (KFLASH)		***
***	Author: Greg Dietsche						***
***	Date:	07/23/2002							***
***	Description: An application designed for	***
*** use with the TI-89 and TI-92 Plus Graphing	***
*** calculators during the testing and			***
*** debugging phases of FLASH APPS and RAM      ***
*** programs									***
***************************************************/

#include <tiams.h>
#include "crash.h"
#include "KFLASHr1.h"
#include "KFLASH.h"
 
////////////////////////////////////////////////////
//static function prototypes                    ///
//////////////////////////////////////////////////
static char* About(void);
static void appExtHelp(AppID self, USHORT strnum);
static void Event_Handler(pFrame self, PEvent e);
static void UpdateAppToolbar(void);
static BOOL CanDelete(AppID self);
static BOOL CanMove(AppID self);
static SINT GetAppErrorContext(void);
static void SetDefaults(void);
static void ShowSysInfo(void);
static BOOL h220xtsrInstalled(void);
static BOOL HW2PatchInstalled(void);
static void ShowAMSInfo(void);
static void ShowBasecode_PB(void);
static void ShowHW_PB(void);

//////////////////////////////////////////////////////
//static data                                     ///
////////////////////////////////////////////////////
static const short AppIcon[];

//////////////////////////////////////////////////

#define FRAME_SIZE (13 + NUM_XR_STRINGS + NUM_OO_USED + NUM_ER_USED + (NUM_EXTENSIONS*3))

APP_EXTENSION const appExtensions[]={
/*		func name #, 										help string # 						func index */
	{OO_FIRST_APP_STRING + XR_extLowMem,		OO_FIRST_APP_STRING + XR_extHelpLowMem,			EXT_LOWMEM},
	{OO_FIRST_APP_STRING + XR_extPeekB,			OO_FIRST_APP_STRING + XR_extHelpPeekB,			EXT_PEEKB},
	{OO_FIRST_APP_STRING + XR_extPeekL,			OO_FIRST_APP_STRING + XR_extHelpPeekL,			EXT_PEEKL},
	{OO_FIRST_APP_STRING + XR_extPeekW,			OO_FIRST_APP_STRING + XR_extHelpPeekW,			EXT_PEEKW},
	{OO_FIRST_APP_STRING + XR_extPokeB,			OO_FIRST_APP_STRING + XR_extHelpPokeB,			EXT_POKEB},
	{OO_FIRST_APP_STRING + XR_extPokeL,			OO_FIRST_APP_STRING + XR_extHelpPokeL,			EXT_POKEL},
	{OO_FIRST_APP_STRING + XR_extPokeW,			OO_FIRST_APP_STRING + XR_extHelpPokeW,			EXT_POKEW},
	{OO_FIRST_APP_STRING + XR_extHeapShuffle,	OO_FIRST_APP_STRING + XR_extHelpHeapShuffle,	EXT_HEAPSHUFFLE}
};

APP_EXT_ENTRY const appExtEntries[]={
/*		&Function(),		type	*/
	{ext_StressTest, 	APP_EXT_FUNCTION},
	{ext_PeekB,			APP_EXT_FUNCTION},
	{ext_PeekL,			APP_EXT_FUNCTION},					
	{ext_PeekW,			APP_EXT_FUNCTION},
	{ext_PokeB,			APP_EXT_FUNCTION},
	{ext_PokeL,			APP_EXT_FUNCTION},
	{ext_PokeW,			APP_EXT_FUNCTION},	
	{ext_HeapShuffle, 	APP_EXT_PROGRAM}
};

FRAME(appObj, OO_SYSTEM_FRAME, 0, OO_APP_FLAGS, FRAME_SIZE)
	ATTR(OO_APP_FLAGS, 					APP_INTERACTIVE) 				//0x0001 APP_BACKGROUND
	ATTR(OO_APP_NAME, 					APP_TITLE)                      //0x0002
	ATTR(OO_APP_TOK_NAME, 				"cmdpost")						//0x0003
	ATTR(OO_APP_PROCESS_EVENT, 			&Event_Handler)                 //0x0004
	ATTR(OO_APP_DEFAULT_MENU, 			&AppMenu)						//0x0005
	ATTR(OO_APP_EXT_COUNT, 				NUM_EXTENSIONS)					//0x0007
	ATTR(OO_APP_EXTENSIONS, 			appExtensions)					//0x0008
	ATTR(OO_APP_EXT_ENTRIES, 			appExtEntries)					//0x0009
	ATTR(OO_APP_CAN_DELETE,				CanDelete)						//0x000C
	ATTR(OO_APP_CAN_MOVE,				CanMove)						//0x000D
	//ATTR(OO_APP_VIEWER,				AppViewer)						//0x000E
	ATTR(OO_APP_ICON,					&AppIcon)						//0c000F
	ATTR(OO_APP_EXT_HELP,				appExtHelp)						//0x0010
	ATTR(OO_APP_ABOUT,					About)							//0x0012
    
//Application Error Strings
    STRING_ATTR(XR_ADDRESS,				"Address Error")
    STRING_ATTR(XR_ILLEGAL,				"Illegal Instruction")
    STRING_ATTR(XR_DIVIDE,				"Divide by Zero")
    STRING_ATTR(XR_CHK,					"CHK Instruction")
    STRING_ATTR(XR_TRAPV,				"TRAPV Instruction")
    STRING_ATTR(XR_PRIV,				"Privilege Violation")
    STRING_ATTR(XR_TRACEINT,			"Trace Interrupt")
    STRING_ATTR(XR_SINT,				"Spurious Interrupt")
    STRING_ATTR(XR_TRAP5,				"Trap #5")
    STRING_ATTR(XR_TRAP6,				"Trap #6")
    STRING_ATTR(XR_TRAP7,				"Trap #7")
    STRING_ATTR(XR_TRAP13,				"Trap #13")
    STRING_ATTR(XR_TRAP14,				"Trap #14")
    STRING_ATTR(XR_TRAP15,				"Trap #15")
	STRING_ATTR(XR_InvalidHandle,		"Invalid Handle")
	STRING_ATTR(XR_InvalidHistItem,		"Invalid History Item")
	
//Application Strings   
	STRING_ATTR(XR_ShortAppName,		APP_TITLE)
	STRING_ATTR(XR_LongAppName,			APP_TITLE " v" APP_VERSION)
	STRING_ATTR(XR_AppVersion,			APP_VERSION)
	STRING_ATTR(XR_Protection,			"Crash Protection")
	STRING_ATTR(XR_ProtectionE,			"Crash Protection" RF_ELLIPSIS)
	STRING_ATTR(XR_On,					"On")
	STRING_ATTR(XR_Off,					"Off")
	STRING_ATTR(XR_PasteSpecial,		"Paste Special")
	STRING_ATTR(XR_About_Me,			APP_TITLE " v"APP_VERSION"\nCopyright " RF_COPYRIGHT " 2002\nBy: Gregory L. Dietsche.\nLast Built: " __DATE__  "\n\nhttp://gforce.calc.org\ngforce@calc.org\n\nDo Not Distribute To\nUnauthorized Persons")
	STRING_ATTR(XR_MemoryInfo,			"RAM Info:\nFree RAM: %lu\nLargest Avail Handle: %lu\nHeap Status: %s\n\nFlash Info:\nFlash Memory End: 0x%lx")
	STRING_ATTR(XR_MemoryStatus,		"Memory Status" RF_ELLIPSIS)
	STRING_ATTR(XR_RAMStress,			"Low RAM Simulation")
	STRING_ATTR(XR_RAMStressE,			"Low RAM Simulation" RF_ELLIPSIS)
	STRING_ATTR(XR_Status,				"Status")
	STRING_ATTR(XR_Bytes,				"Bytes")
	STRING_ATTR(XR_Enabled,				"Enabled")
	STRING_ATTR(XR_Disabled,			"Disabled")
	STRING_ATTR(XR_UseXbytes,			"Use")
	STRING_ATTR(XR_LeaveBytesFree,		"All Except")
	STRING_ATTR(XR_HexEditor,			"Hex Editor")
    STRING_ATTR(XR_HeapCorrupted,		"WARNING:\nThe Heap Has Been Corrupted! Resetting This Calculator Is Strongly Recommended.")
    STRING_ATTR(XR_LowMemFmtStr,		"main\\lowmem%02x")	//'@' is a fast way of hiding a var
    STRING_ATTR(XR_HeapShuffle,			"Heap Shuffle")
    STRING_ATTR(XR_HeapVaild,			"Valid")
    STRING_ATTR(XR_HeapInvalid,			"Corrupt")
    STRING_ATTR(XR_SetDefaults,			"Set Defaults")
    STRING_ATTR(XR_SystemInfo,			"ASM PRGM Support" RF_ELLIPSIS)
    STRING_ATTR(XR_Refresh,				"Refresh")
	STRING_ATTR(XR_UnknownKernel,		"Unknown Kernel")
	STRING_ATTR(XR_NoKernelFound,		"No Kernel Found")
	STRING_ATTR(XR_h220xtsr,			"h220xtsr")
	STRING_ATTR(XR_HW2Patch,			"HW2 Patch")
	STRING_ATTR(XR_NoHwPatchFound,		"No HW Patch Found")
	STRING_ATTR(XR_NotApplicable,		"Not Applicable")
	STRING_ATTR(XR_SysInfoStr,			"Extended ASM PRGM Support Info:\n\nHW Version: %lu.00\nKernel: %s\nHW Patch: %s")
	STRING_ATTR(XR_LeakWatchStr,		C("Possible Memory Leak:\n\n   Init RAM: %ld\nFinal RAM: %ld\nDelta RAM: %ld\n\n   Init Vars: %ld\nFinal Vars: %ld\nDelta Vars: %ld", 
										  "Possible Memory Leak:\n\n Init RAM: %ld\nFinal RAM: %ld\nDelta RAM: %ld\n\n Init Vars: %ld\nFinal Vars: %ld\nDelta Vars: %ld"))
	STRING_ATTR(XR_LeakWatch,			"Leak Watch")
	STRING_ATTR(XR_LeakWatchE,			"Leak Watch" RF_ELLIPSIS)
	STRING_ATTR(XR_InstallHook,			"Install Hook")
	STRING_ATTR(XR_RemoveHook,			"Remove Hook")
	STRING_ATTR(XR_Action,				"Action")
	STRING_ATTR(XR_Application,			"Application")
	STRING_ATTR(XR_AllApps,				"All Applications")
	STRING_ATTR(XR_JumpTo,				"Jump To")
    STRING_ATTR(XR_Handle,				"Handle")
    STRING_ATTR(XR_Address,				"Address")
	STRING_ATTR(XR_ValueC,				"Value:")
	STRING_ATTR(XR_LeakPackInfo,		"The Command Post leak watch module has been uninstalled to allow this application (%s) to pack and move to a new memory location.\nIf continued monitoring is desired, the leak watch module must be reinstalled manually.")
	STRING_ATTR(XR_LeakWatchInstall,	"Leak Watch is now monitoring %s.")
	STRING_ATTR(XR_LeakWatchRemove,		"Leak Watch is no longer monitoring %s.")
	STRING_ATTR(XR_Byte,				"Byte")
	STRING_ATTR(XR_Word,				"Word")
	STRING_ATTR(XR_Long,				"Long")
	STRING_ATTR(XR_PasteSpecialO,		C("Paste Special" RF_ELLIPSIS,
										  "Paste Special" RF_ELLIPSIS "\t" RF_OPTION "V"))
	STRING_ATTR(XR_PasteTruncated,		"Warning: Paste string truncated!")
	STRING_ATTR(XR_KernelWarning,		"Warning: A kernel has been detected.\n\nPlease temporarily uninstall the kernel and wait for a message confirming the successful backup of the system vector table.")
	STRING_ATTR(XR_SuccessfulBackup,	"A backup of the system vector table has been made. Any kernel that was previously removed may be reinstalled if desired.")
	STRING_ATTR(XR_AMSInfo,				"AMS Info" RF_ELLIPSIS)
	STRING_ATTR(XR_BasecodePB,			"Basecode Parm Block:\nLength: 0x%x\nVersion Number: 0x%x\nVersion Date: 0x%lx")
	STRING_ATTR(XR_BasecodePBE,			"Basecode Parm Block" RF_ELLIPSIS)
	STRING_ATTR(XR_HardwarePB,			"Hardware Parm Block")
	STRING_ATTR(XR_HardwarePBE,			"Hardware Parm Block" RF_ELLIPSIS)
	STRING_ATTR(XR_HardwarePBStr,		C("  Hardware ID:\n  Hardware Revision:\n  Boot Major:\n  Boot Revision:\n  Boot Build:\n  Gate Array:\n  Logical LCD Width:\n  Logical LCD Height:\n  Physical LCD Width:\n  Physical LCD Height:", 
										  " Hardware ID:\n Hardware Revision:\n Boot Major:\n Boot Revision:\n Boot Build:\n Gate Array:\n Logical LCD Width:\n Logical LCD Height:\n Physical LCD Width:\n Physical LCD Height:"))
	STRING_ATTR(XR_HWPBTooLong,			"HW Parm Block is longer than expected")
	STRING_ATTR(XR_Variable,			"Variable" RF_ELLIPSIS)
	STRING_ATTR(XR_JumpToE,				"Address or Handle" RF_ELLIPSIS)
	STRING_ATTR(XR_EditE,				"Edit" RF_ELLIPSIS "\t \n")
	STRING_ATTR(XR_JUMPTO,				"JUMP TO")
	STRING_ATTR(XR_Data,				"Data")
	STRING_ATTR(XR_SymEntry,			"Sym Entry")
	STRING_ATTR(XR_Find,				"Find")
	STRING_ATTR(XR_Foreword,			"Foreword")
	STRING_ATTR(XR_Backward,			"Backward")
	STRING_ATTR(XR_CantDelete,			"Please disable leak watch monitoring from all active applications before uninstalling " APP_TITLE ".")
	STRING_ATTR(XR_SearchingEstr,		"Searching" RF_ELLIPSIS "  Press <ON> to abort")
	STRING_ATTR(XR_FindNextO,			"Find Next\t<CLR>")
	STRING_ATTR(XR_HexEditorWidth,		"Hex Editor Width")
	STRING_ATTR(XR_TwoBytes,			"Two Bytes")
	STRING_ATTR(XR_FourBytes,			"Four Bytes")
	STRING_ATTR(XR_SixBytes,			"Six Bytes")
	STRING_ATTR(XR_EightBytes,			"Eight Bytes")
	STRING_ATTR(XR_TenBytes,			"Ten Bytes")
	STRING_ATTR(XR_Automatic,			"Automatic")
	STRING_ATTR(XR_ResizeHandleE,		"Resize Handle" RF_ELLIPSIS)
	STRING_ATTR(XR_NewSize,				"New Size")
	STRING_ATTR(XR_RESIZEHANDLE,		"RESIZE HANDLE")
	STRING_ATTR(XR_NewValue,			"New Value")
	STRING_ATTR(XR_Direction,			"Direction")
	STRING_ATTR(XR_BOTTOM_ESTACK,		"bottom_estack")
    STRING_ATTR(XR_CU_CURSOR_STATE,		"CU_cursorState")
    STRING_ATTR(XR_ERRNO,				"errno")
    STRING_ATTR(XR_ESTACK_MAX_INDEX,	"estack_max_index")
    STRING_ATTR(XR_EV_APPA,				"EV_appA")
    STRING_ATTR(XR_EV_APPB,				"EV_appB")			
    STRING_ATTR(XR_EV_ERROR_CODE,		"EV_errorCode")
    STRING_ATTR(XR_EV_FLAGS,			"EV_flags")
    STRING_ATTR(XR_EV_RUNNINGAPP,		"EV_runningApp")
    STRING_ATTR(XR_FLASHMEMORYEND,		"FlashMemoryEnd")
    STRING_ATTR(XR_MO_OPTION,			"MO_option")
    STRING_ATTR(XR_NG_CONTROL,			"NG_control")
    STRING_ATTR(XR_OO_FIRST_ACB,		"OO_firstACB")		
    STRING_ATTR(XR_OO_SUPERFRAME,		"OO_SuperFrame")
    STRING_ATTR(XR_OSFASTARROWS,		"OSFastArrows")		
    STRING_ATTR(XR_OSMODKEYSTATUS,		"OSModKeyStatus")
    STRING_ATTR(XR_ST_FLAGS,			"ST_flags")
    STRING_ATTR(XR_TOP_ESTACK,			"top_estack")
    STRING_ATTR(XR_HistoryItem,			"History Item")
    STRING_ATTR(XR_HS_getAns,			"HS_getAns")
    STRING_ATTR(XR_HS_getEntry,			"HS_getEntry")
    STRING_ATTR(XR_JumpAMSGlobalVar,	"AMS Global Variable" RF_ELLIPSIS)
    STRING_ATTR(XR_JumpTable,			"Jump Table")
    STRING_ATTR(XR_FindPreviousO,		"Find Previous\t" RF_OPTION "<CLR>")
    STRING_ATTR(XR_Jump,				"Jump")
    STRING_ATTR(XR_FindO,				"Find" RF_ELLIPSIS "\t" RF_OPTION "\n")
    STRING_ATTR(XR_CopySpecialO,		C("Copy Special" RF_ELLIPSIS, 
    									  "Copy Special" RF_ELLIPSIS "\t" RF_OPTION "C"))
    STRING_ATTR(XR_COPYSPECIAL,			"COPY SPECIAL")
   	
//App Extensions
    STRING_ATTR(XR_extLowMem,			"LowMem")
    STRING_ATTR(XR_extPeekB,			"PeekB")
    STRING_ATTR(XR_extPeekL,			"PeekL")
    STRING_ATTR(XR_extPeekW,			"PeekW")
    STRING_ATTR(XR_extPokeB,			"PokeB")
    STRING_ATTR(XR_extPokeL,			"PokeL")
    STRING_ATTR(XR_extPokeW,			"PokeW")
	STRING_ATTR(XR_extHeapShuffle,		"Shuffle")
	    
//App extension help strings
    STRING_ATTR(XR_extHelpLowMem,		"[enabled], [mode], [bytes]")
    STRING_ATTR(XR_extHelpPeekB,		"any address")
	STRING_ATTR(XR_extHelpPeekL,		"even address")
    STRING_ATTR(XR_extHelpPeekW,		"even address")
    STRING_ATTR(XR_extHelpPokeB,		"any address, new value")
	STRING_ATTR(XR_extHelpPokeL,		"even address, new value")
    STRING_ATTR(XR_extHelpPokeW,		"even address, new value")
    STRING_ATTR(XR_extHelpHeapShuffle,	"Shuffle memory blocks in the heap")

//App ext extension help strings
//RF_ARROW_RIGHT    
    STRING_ATTR(XR_extextHelpLowMem,		"LowMem([enabled], [mode], [bytes])"RF_ARROW_RIGHT"list\n\nenabled = {1=ON, 2=OFF}\nmode = {1=All Except, 2=Use}\nbytes = {Number of Bytes}\n\nThe previous"
    										" (or current if no arguments are passed) mode settings will be returned as a list.")
    STRING_ATTR(XR_extextHelpPeekB,			"PeekB(address)"RF_ARROW_RIGHT"int\n\nReads one byte from the specified memory address and returns the result.")
    STRING_ATTR(XR_extextHelpPeekL,			"PeekL(address)"RF_ARROW_RIGHT"int\n\nReads one long (4 bytes) from the given memory address and returns the result. If the passed address is odd, an Address Error is thrown.")
    STRING_ATTR(XR_extextHelpPeekW,			"PeekW(address)"RF_ARROW_RIGHT"int\n\nReads one word (2 bytes) from the given memory address and returns the result. If the passed address is odd, an Address Error is thrown.")
    STRING_ATTR(XR_extextHelpPokeB,			"PokeB(address, new value)"RF_ARROW_RIGHT"int\n\nWrites one byte to the given memory address. The previous (BYTE) value pointed to by the given address is returned.")
    STRING_ATTR(XR_extextHelpPokeL,			"PokeL(address, new value)"RF_ARROW_RIGHT"int\n\nWrites one long (4 bytes) to the specified memory address. The previous (long) value pointed to by the given address is returned.")
    STRING_ATTR(XR_extextHelpPokeW,			"PokeW(address, new value)"RF_ARROW_RIGHT"int\n\nWrites one word (2 bytes) to the specified memory address. The previous (WORD) value pointed to by the given address is returned.")
    STRING_ATTR(XR_extextHelpHeapShuffle,	"Shuffle()\n\nShuffle memory blocks in the heap. Equivalent to AMS rom call HeapShuffle();")

//App Data Interface      
	ATTR(OO_PROTECTION_ACTIVE,			&global.AntiCrashInstalled)		//0x10000
	ATTR(OO_REDIRECTED_VECT,			gRedirect)
	ATTR(OO_VECTORS,					gVectors)
	ATTR(OO_OLD_VECTORS,				global.old_vectors)
	ATTR(OO_VECT_REDIR,					NUM_VECT_REDIR)
	ATTR(OO_VECT_SAVED,					NUM_VECT_SAVED)
	ATTR(OO_BACKUP_VECTORS,				MakeExceptionVectorBackup)
	ATTR(OO_INSTALL_VECTORS,			EnableCrashProtection)
	ATTR(OO_UNINSTALL_VECTORS,			DisableCrashProtection)
	ATTR(OO_KERNELS,					gKernels)
	ATTR(OO_KERNELIDS,					gKernelID)
	ATTR(OO_NUM_KERNELS,				NUM_KERNELS)
	ATTR(OO_LEAK_WATCH_BEGIN,			export_LeakWatchBegin)			
	ATTR(OO_LEAK_WATCH_END,				export_LeakWatchEnd)
	
ENDFRAME

//////////////////////////////////////////////////
//Application Data Section					  ///
////////////////////////////////////////////////

/* Pointer to the Frame object */
	pFrame pAppObj = (pFrame)&appObj;  /* Must be first! */

//This is a bitmap structure, NOT an icon as suggested by the FRAME entry
static const short AppIcon[]={
	0x0012,	//Num Rows	/\
	0x0014,	//Num Cols	<->
	//icon data            	
	0x01fe,0x0007,0xff80,0x3c09,0xc069,0x50e0,0xe027,0x60c5,0x1f30,0xd077,
	0x70e5,0xec30,0xc8f9,0x70c2,0xf030,0xe904,0xe072,0xa1e0,0x690b,0xc03f,
	0xff80,0x3ffc,0x0009,0x2600,0x1b33,0x0032,0x1180
};

/* The Primary Window For The GUI portion of this app */
	WINDOW appW;
		
/* New Exception Vector Handlers */
	long gRedirect[NUM_VECT_REDIR]={
		(long)Exception_0,
		(long)Exception_1,
		(long)Exception_2,
		(long)Exception_3,
		(long)Exception_4,
		(long)Exception_5,
		(long)Exception_6,
		(long)Exception_7,
		(long)Exception_8,
		(long)Exception_9,
		(long)Exception_10,
		(long)Exception_11,
		(long)Exception_12,
		(long)Exception_13,
	};

/* A Global List Of Vectors  */
	short gVectors[NUM_VECT_SAVED]={
	/* Addresses of Exceptions to be Trapped */
		VECT_ADDR_sh(3),		//Address Error									Type 0
		VECT_ADDR_sh(4),		//Illegal Instruction 							Type 1
		VECT_ADDR_sh(5),		//Divide by Zero								Type 2
		VECT_ADDR_sh(6),		//CHK Instruction								Type 2
		VECT_ADDR_sh(7),		//TRAPV Instruction								Type 2
		VECT_ADDR_sh(8),		//Privilege Violation							Type 1
		VECT_ADDR_sh(9),		//Trace											Type 1
		VECT_ADDR_sh(24),		//Spurious Interrupt							Type 1
		VECT_ADDR_sh(37),		//Trap #5										Type 2
		VECT_ADDR_sh(38),		//Trap #6										Type 2
		VECT_ADDR_sh(39),		//Trap #7										Type 2
		VECT_ADDR_sh(45),		//Trap #13										Type 2
		VECT_ADDR_sh(46),		//Trap #14										Type 2
		VECT_ADDR_sh(47),		//Trap #15										Type 2
		
	/* Other Vectors That Need To Be Backed Up */
		VECT_ADDR_sh(25),		//AI 1
		VECT_ADDR_sh(26),		//AI 2
		VECT_ADDR_sh(27),		//AI 3
		VECT_ADDR_sh(28),		//AI 4
		VECT_ADDR_sh(29),		//AI 5
		VECT_ADDR_sh(30)		//AI 6
	};

/* List of Known Kernel String Pointers */
char * gKernels[NUM_KERNELS]={
	"KerNO",		/* KerNO is not a true kernel, but it mimicks some features found in 'real' kernels */
	"Universal OS",
	"Lex OS",
	"TEOS",
	"Plusshell",	/* A Piece of History: Plusshell was the _first_ kernel for the 89/92p */
	"Doors OS",
	"PreOS",
};

/* Corresponds to gKernels this number should be found at 0x32.w */
USHORT gKernelID[NUM_KERNELS]={
	0x4B4E,	//#'KN'
	0x554F,	//#'UO'
	0x4c58,	//#'LX'
	0x544F,	//#'TO'
	0x5053,	//#'PS'
	0x4454,	//#'DN'
	0x504F	//#'PO'
};

/* All Variables that need to be saved with CM_PACK and restored later with CM_UNPACK */
	PACK_DAT global;

/* For Delayed Handling of Errors */
	SINT gDelayedErrorNum;

/* For Routines that need to return a pointer to a static(locked) buffer */
	char gBuff[MISC_BUFF_LEN + 1];
//////////////////////////////////////////////////

static void Event_Handler(pFrame self, PEvent e)
{
    Access_AMS_Global_Variables;
    
	WIN_RECT appWR;
	volatile HANDLE storage;
	PACK_DAT *pstorage;
	
//they say put it here... i'm thinking that it could go in the CM_INSTALL handler...
	OS_NeedMinimumVersion(pAppObj, 2, 5);		//require AMS 2.05 or better	
  
	switch (e->command)
	{	
		case CM_BACKGROUND:	//handle this as quickly as possible

			if(!*(USHORT*)0x32)	//if a kernel is not (no longer) installed attempt to make a clean vector backup
			{
				/*
					if kernel no longer installed
					anti crash protection (this app) is in undefined state.. may be off or on regardless of what the global variable says
					the user _should_ not have enough time to beat the CM_BACKGROUND event (subjective) and turn on this apps anti-crash protection
					therefore, implicitly backup current vector table (no checks for installed anti-crash support)
					and if the crash protect enabled flag is set, reinstall this apps crash protection vectors
					this should get a reliable vector backup and restore the crash protection to a known state
				*/
				
				ACB *self=(ACB*)HeapDeref(GetMyAppID());			//get a pointer to my ACB
				ULONG flags=(ULONG)OO_AbsoluteGet(OO_APP_FLAGS);	//\
				flags&=~APP_BACKGROUND;								//->the os seems to ignore this, but if it ever does get smarter... i will have it covered :)
				OO_AbsoluteSet(OO_APP_FLAGS, (void *)flags);		///
				
				self->flags&=~ACB_BG;	//unset the acb background event flag (the ams listens to this)
				
				BackupExceptionVectors(OO_AbsoluteGet(OO_VECTORS), OO_AbsoluteGet(OO_OLD_VECTORS), (short)OO_AbsoluteGet(OO_VECT_SAVED));
				if(global.AntiCrashInstalled)EnableCrashProtection();
				
				DlgNotice(OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LongAppName),
					OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_SuccessfulBackup));
			}
			return;	//return as quickly as possible
			//do_LowMemStressTest();//active lowmem simulation versus passive
		break;
		
		case CM_DEFAULTS:
			SetDefaults();
		break;
						
		case CM_INSTALL:
			MakeExceptionVectorBackup();
			//h220xtsrInstalled()
			if(*(USHORT*)0x32)	//if a kernel is not installed
			{//no need to mess with the ACB in the install event because the ams will set that flag for me
			//if the APP_BACKGROUND flag is set in my frame
				ULONG flags=(ULONG)OO_AbsoluteGet(OO_APP_FLAGS);
				flags|=APP_BACKGROUND;
				OO_AbsoluteSet(OO_APP_FLAGS, (void *)flags);
				
				DlgNotice(OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LongAppName),
					OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_KernelWarning));
			}
			SetDefaults();
		break;
		
		case CM_UNINSTALL:
			DisableCrashProtection();
			LeakWatchNone();
			
			if(storage=OO_appGetPublicStorage())	//free any mem that was used for CM_PACK/UNPACK
				HeapFree(storage);				
		break;
		
		case CM_PACK:
			storage  = OO_appGetPublicStorage();
			pstorage = HeapDeref(storage);
		   *pstorage = global;					
		break;
		
		case CM_UNPACK:
			storage  = OO_appGetPublicStorage();
			pstorage = HeapDeref(storage);
			global   = *pstorage;
		break;
		
		case CM_START:
			gDelayedErrorNum=0;	//clear any previous error context
			
			appWR = *(e->info.startInfo.startRect);
         	if (!WinOpen(&appW, &appWR,  WF_DUP_SCR))
            	gDelayedErrorNum=ER_MEMORY;
		break;
		
		case CM_FOCUS:
			if(GetAppErrorContext())
			{
			 	EV_errorCode=GetAppErrorContext();
			 	EV_quit();
			}
		break;
		
		case CM_QUIT:
			//if(GetAppErrorContext())break;	//the app is exiting in error
			if(appW.Next)
			{
				WinClose(&appW);
				appW.Next=NULL;
			}
			
		//enforce the Stress Test settings
		if(global.stress_dat.optList[OPT_STATUS]==STRESS_ENABLE)
			do_LowMemStressTest();
			
		break;
		
      	case CM_ACTIVATE:
      		if(GetAppErrorContext())break;	//the app is exiting in error      		
			
			EV_defaultHandler(e);			
			UpdateAppToolbar();
			
			WinBeginPaint(&appW);
			
			MO_currentOptions();
			if(MO_option[MO_OPT_SPLIT_SCREEN]!=1) WinActivate(&appW);
		break;
		
		case CM_DEACTIVATE:
			if(GetAppErrorContext())break;	//the app is exiting in error
				
			EV_defaultHandler(e);
			WinEndPaint(&appW);
		break;
		
		case CM_ABOUT:
			DlgNotice(XR_stringPtr(XR_LongAppName), About());
		break;                                        
		
		case ACM_ProtectionON:
			EnableCrashProtection();
			UpdateAppToolbar();
		break;
		
		case ACM_ProtectionOFF:
			DisableCrashProtection();
			UpdateAppToolbar();
		break;
		
		case ACM_RAMStats:
			DoRAMStatsDialog();		
		break;
		
		case ACM_BasecodePB:
			ShowBasecode_PB();
		break;
		
		case ACM_HW_PB:
			ShowHW_PB();		
		break;
		
		case ACM_RAMStressDialog:
			DoStressTestDialog();		
		break;
		
		case ACM_HeapShuffle:
			ext_HeapShuffle();
		break;
		
		case ACM_Defaults:
			SetDefaults();
			DlgNotice(XR_stringPtr(XR_LongAppName), XR_stringPtr(XR_cResetDefaults));
		break;
		
		case ACM_SysInfo:
			ShowSysInfo();		
		break;
		
		case ACM_AMS_Info:
			ShowAMSInfo();
		break;
		
		case ACM_LeakWatch:
			LeakWatchDialog();
		break;
						
		default:
			HexEditorEventLoop(self, e);	//fix for CM_PASTE_HANDLE Events
			EV_defaultHandler(e);
			return;
		break;
	}
	
//pass all events on to the Hex Editor portion of this app for possible further processing
	if(!GetAppErrorContext())
		HexEditorEventLoop(self, e);
}

//Implements the About Screen and About Frame Attribute about string
static char* About(void)
{//This app may not be active when this function is called, so use
//a lookup method that will not fail
	return OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_About_Me);
}

//The app must be active, and have the default tool bar drawn for this routine to work!
static void UpdateAppToolbar(void)
{
	register volatile HANDLE h=(const HANDLE)OO_AbsoluteGet(OO_APP_DEFAULT_MENU_HANDLE);
	register BOOL x=global.AntiCrashInstalled;
		
	MenuCheck(h, ACM_ProtectionON,  x?MC_CHECK:MC_UNCHECK);	//set/unset crash protection check marks 
	MenuCheck(h, ACM_ProtectionOFF, x?MC_UNCHECK:MC_CHECK);  //set/unset crash protection check marks
}

static BOOL CanMove(AppID self)
{//This app MUST_NOT_MOVE if it can not save its current state,
 // or the saved exception vector table will be lost!
 // memory allocated here will be HeapFree()d when the app is CM_UNINSTALLed
	HANDLE storage;
	//OO_appSet/GetPublicStorage WILL NOT WORK in this instance because the appid can be different than this apps id
	ULONG *pubstorage=&((ACB*)HeapDeref(GetMyAppID()))->publicstorage;
	
	if(!*pubstorage)				//Handle has not been allocated
	{
		if(!(storage=HeapAllocHigh(sizeof(PACK_DAT))))	//attempt to allocate storage
			return FALSE;
			
		//OO_appSetPublicStorage(storage);			//storage allocated successfully
		*pubstorage=(ULONG)storage;
	}
	
  	return LeakWatchAppsNotActive();	//can't move if a hooked app is active
}

static BOOL CanDelete(AppID self)
{
	register candel=LeakWatchAppsNotActive();	//can't delete if a LeakWatched app is active (CM_UNINSTALL removes all active Leak Watch hooks)
	
	if(!candel)
		DlgNotice(OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LongAppName),
				  OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_CantDelete));
	return candel;
}

//This leaves room for future expansion while saving a few bytes too
static SINT GetAppErrorContext(void)
{
	return gDelayedErrorNum;
}

//responsible for restoring 'factory' settings
static void SetDefaults(void)
{
	PACK_DAT *p_dat=&global;
	
//defaults for LowMem
	p_dat->stress_dat.optList[OPT_STATUS]=STRESS_DISABLE;
	p_dat->stress_dat.optList[OPT_MODE]=STRESS_MODE_FILL;
	strcpy(p_dat->stress_dat.txtBytes,"200");
	
	p_dat->hex_dat.top=(char*)0x0;
	p_dat->hex_dat.addr=0;
	
	p_dat->leak_dat.optList[0]=1;
	p_dat->leak_dat.optList[1]=1;
	
	LeakWatchNone();
	do_LowMemStressTest();
	
//by default, anti-crash protection is activated if no Kernel is Installed
	if(!*(USHORT*)0x32)
		EnableCrashProtection();
	else
		DisableCrashProtection();
}

static void appExtHelp(AppID self, USHORT strnum)
{
	DlgNotice(OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LongAppName), 
				OO_AbsoluteGet(OO_FIRST_APP_STRING + FIRST_EXT_HELP_STR + strnum));
}

static void ShowSysInfo(void)
{
	char buff[500];
	char *kptr, *patchptr;
	short kernel;
	USHORT count=(short)OO_AbsoluteGet(OO_NUM_KERNELS);
	char **kstr=(char **)OO_AbsoluteGet(OO_KERNELS);
	USHORT *knum=(USHORT *)OO_AbsoluteGet(OO_KERNELIDS);
	
	for(kernel=0; kernel<count; kernel++)
	{
		if(*(USHORT*)0x32 == knum[kernel])
			break;
	}
	
	if(kernel==count)
		kptr=*(USHORT *)0x32?XR_stringPtr(XR_UnknownKernel):XR_stringPtr(XR_NoKernelFound);
	else
		kptr=kstr[kernel];
	
	if(FL_getHardwareParmBlock()->hardwareRevision)
	{
		if(h220xtsrInstalled())patchptr=XR_stringPtr(XR_h220xtsr); else
		if(HW2PatchInstalled())patchptr=XR_stringPtr(XR_HW2Patch); else
		patchptr=XR_stringPtr(XR_NoHwPatchFound);
	}
	else
		patchptr=XR_stringPtr(XR_NotApplicable);
	
	sprintf(buff, XR_stringPtr(XR_SysInfoStr), AB_getGateArrayVersion(), kptr, patchptr);
	DlgNotice(XR_stringPtr(XR_LongAppName), buff);

}

static void ShowAMSInfo(void)
{
	Access_AMS_Global_Variables;
	char serno[17];
	char prodname[40];
	char prodid[12];  
	char buff[500];
	
	AB_prodid(prodid);
	AB_prodname(prodname);
	AB_serno(serno);
	
	sprintf(buff, "%s\n%s\n%s %s\n%s %s\n%s %s",
	XR_stringPtr(XR_ModelName), prodname, ReleaseVersion, ReleaseDate, XR_stringPtr(XR_ProductIDCB), prodid,
	XR_stringPtr(XR_SerialNum), serno);
	
	DlgNotice(XR_stringPtr(XR_LongAppName), buff);
}

/*static void Show HWParmBlock()
{
	HARDWARE_PARM_BLOCK *hpb=FL_getHardwareParmBlock();
	//(hpb->len >= OFFSETOF(HARDWARE_PARM_BLOCK, LCDBitsTall))
	
}*/

static BOOL h220xtsrInstalled(void)
{		
	switch(*(unsigned long*)(*(unsigned long*)0xAC-8))
	{
		case 0x32547372:	//2Tsr (new signature)
		case 0x32545352:	//2TSR (old signature)
			return TRUE;
		break;
		
		default:
			return FALSE;		
	}
}

//this is a documented rom call, but the implementation dosen't allow getting the address of the function
//so i have fixed the problem...
#define addr_EX_stoBCD ((char *)AMS_Global_Variables[0xC0])
static BOOL HW2PatchInstalled(void)
{
Access_AMS_Global_Variables;

  register unsigned long *ptr;
  
  if (*(unsigned long *)0xAC == 0x100) return 1;	//RAM resident
  
  ptr = (unsigned long *)((addr_EX_stoBCD)+0x52);
  
  //if (ptr[0]!=0x700000) return 2;	//ROM resident
  if (ptr[1]!=0x36BCFFDF) return 2;	//ROM resident
  
  return FALSE;
}

DWORD NoCallBack(WORD DlgId, DWORD Value) { return TRUE; }

//replacement for tios GetValue
/*
	Less error checking is done... use push_simplify before calling
*/
unsigned long GetLongArg(EStackIndex index, unsigned long rLow, unsigned long rHigh)
{
	Quantum tag=*index;
	register short quantum;	//number of quantums
	register unsigned long result=0;
	
	if(tag==SECONDARY_TAG)
	{//handle bin and hex numbers
		tag=*--index;
		if(tag!=BIN_NUM_TAG && tag!=HEX_NUM_TAG) ER_throw(ER_DATATYPE);
		tag=*--index;
	}
	
	quantum=*(--index);
	
	if(tag!=NONNEGATIVE_INTEGER_TAG && tag!=NEGATIVE_INTEGER_TAG) ER_throw(ER_DATATYPE);
		
	if(quantum>4) ER_throw(ER_DOMAIN);
	
	while(quantum--)
	{
		result=(result<<8) + *(--index);
	}
	
	result=tag==NONNEGATIVE_INTEGER_TAG?result:-result;
	
	if(result>rHigh)ER_throw(ER_DOMAIN);
	if(result<rLow)ER_throw(ER_DOMAIN);
	
	return result;
}

long StrToEStackToLong(char *str)
{
	Access_AMS_Global_Variables;
	EStackIndex oldtop=top_estack;
	long retval=0;	//satisfy the compiler
	char buff[500];
	
//i'm not sure how to get the equivalent of int(exact(str)) on the estack so this works for me :)
//essentially, this forces the result to be more exact than exact ... ie a _perfect_ integer
	strcpy(buff, XR_stringPtr(XR_intP));
	strcat(buff, XR_stringPtr(XR_exactP));
	strcat(buff, str);
	strcat(buff, "))");

	TRY
		SET_SIDE_EFFECTS_FORBIDDEN;
		push_quantum(END_OF_SEGMENT_TAG);
		push_parse_text((BYTE *)buff);
		push_simplify_statements(top_estack);
		retval=GetLongArg(top_estack, 0, ULONG_MAX);
	FINALLY
		SET_SIDE_EFFECTS_PERMITTED;
		top_estack=oldtop;
	ENDFINAL
		
	return retval;		
}

static void ShowBasecode_PB(void)
{
	char buff[500];
	BASECODE_PARM_BLOCK const *b=EX_getBasecodeParmBlock();
	
	sprintf(buff, XR_stringPtr(XR_BasecodePB), b->len, b->version_number, b->version_date);
	DlgNotice(XR_stringPtr(XR_LongAppName), buff);
}

static void ShowHW_PB(void)
{
	USHORT *pbs=(USHORT*)FL_getHardwareParmBlock();
	ULONG *pb;
	WIN_RECT wRegion={C(30, 30), C(4, 6), C(130, 215), C(88, 113)};
	WINDOW win;
	WORD key=0;
	USHORT len;
	WIN_COORDS ypos=1-C(6, 8);
	char buff[100];
	
	if(!WinOpen(&win, &wRegion, WF_SAVE_SCR|WF_TTY|WF_TITLE|WF_ROUNDEDBORDER, XR_stringPtr(XR_HardwarePB)))
		ER_throw(ER_MEMORY);
	
	WinBeginPaint(&win);
	
	#ifdef _89
		WinFont(&win, F_4x6);
	#endif
	
	WinClr(&win);
	WinStr(&win, XR_stringPtr(XR_HardwarePBStr));
	DrawStaticButton(&win, PDB_OK, 5);
	
	len=*pbs;
	pbs++;
	pb=(ULONG*)pbs;
	len-=2;
	
	if(len>0x28)
	{
		ST_helpMsg(XR_stringPtr(XR_HWPBTooLong));
		len=0x28;
	}
	
	len=len/4;
	while(len)
	{
		sprintf(buff, "%lu", *pb++);
		len--;
		WinStrXY(&win, C(75, 131), ypos+=C(6, 8), buff);
	}
	
	ST_busy(ST_IDLE);
	while(key!=KB_ENTER && key!=KB_ESC)
	{
		if(kbhit())
			key=ngetchx();
	}
	
	WinEndPaint(&win);
	WinClose(&win);	
}

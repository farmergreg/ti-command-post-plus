/**************************************************
***	Project Title: Command Post (KFLASH)		***
***	Author: Greg Dietsche						***
***	Date:	07/23/2002							***
***	Description: An application designed for	***
*** use with the TI-89 and TI-92 Plus Graphing	***
*** calculators during the testing and			***
*** debugging phases of FLASH APPS and RAM      ***
*** programs									***
***************************************************/

#include <tiams.h>
#include "crash.h"
#include "oo.h"
#include "ram.h"
#include "KFLASH.h"

static void RestoreLCD(void);
	 
static void ProcessException(short exception)
{   
//Restore saved state info and attempt crash recovery
	SetExceptionVectors(OO_AbsoluteGet(OO_VECTORS), OO_AbsoluteGet(OO_OLD_VECTORS),     (short)OO_AbsoluteGet(OO_VECT_SAVED));
	SetExceptionVectors(OO_AbsoluteGet(OO_VECTORS), OO_AbsoluteGet(OO_REDIRECTED_VECT), (short)OO_AbsoluteGet(OO_VECT_REDIR));
	//PortRestore();	//is this against contest rules? it would help with grayscale programs...
	OSLinkClose();
	OSSetSR(0);
	
//check the heap for validity
	if(!HeapWalk(H_WALK_VERIFY))
		DlgNotice(OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LongAppName),
					OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_HeapCorrupted));

	RestoreLCD();
	
//Finally, Throw the error	
	ER_throwFrame(exception, pAppObj);
}

//Macros that handle an exception based upon the error frame type stacked
#define ER_FRAME_ZERO(s) { asm("lea 14(sp),sp", 4); asm("move.w #0x700, sr", 4); ProcessException(s); }
#define ER_FRAME_ELSE(s) { asm("addq.l #6,sp",  2); asm("move.w #0x700, sr", 4); ProcessException(s); }

void Exception_0(void)	{ ER_FRAME_ZERO(ER_Address); } //"Address Error"
void Exception_1(void)  { ER_FRAME_ELSE(ER_Illegal); } //"Illegal Instruction"
void Exception_2(void)  { ER_FRAME_ELSE(ER_Divide);  } //"Divide by Zero"
void Exception_3(void)  { ER_FRAME_ELSE(ER_CHK);     } //"CHK Instruction"
void Exception_4(void)  { ER_FRAME_ELSE(ER_TrapV);   } //"TRAPV Instruction"
void Exception_5(void)  { ER_FRAME_ELSE(ER_Priv);    } //"Privilege Violation"
void Exception_6(void)  { ER_FRAME_ELSE(ER_TraceInt);} //"Trace Interrupt"
void Exception_7(void)  { ER_FRAME_ELSE(ER_SpIntr);  } //"Spurious Interrupt"
void Exception_8(void)  { ER_FRAME_ELSE(ER_Trap5);   } //"Trap #5"
void Exception_9(void)  { ER_FRAME_ELSE(ER_Trap6);   } //"Trap #6"
void Exception_10(void) { ER_FRAME_ELSE(ER_Trap7);   } //"Trap #7"
void Exception_11(void) { ER_FRAME_ELSE(ER_Trap13);  } //"Trap #13"
void Exception_12(void) { ER_FRAME_ELSE(ER_Trap14);  } //"Trap #14"
void Exception_13(void) { ER_FRAME_ELSE(ER_Trap15);  } //"Trap #15"

	
void SetExceptionVectors(const short vect_list[], const long new_vect[], short num)
{
	short x;
	for(num--;num>-1;num--)
	{
		SET_VECTOR(vect_list[num], new_vect[num]);
	}
}

void BackupExceptionVectors(const short vlist[], long vsaved[], short num)
{
	for(num--;num>-1;num--)
	{
		vsaved[num]=(long)GET_VECTOR((long)vlist[num]);
	}
}

void EnableCrashProtection(void)
{//install own crash protection vectors
	SetExceptionVectors(OO_AbsoluteGet(OO_VECTORS), OO_AbsoluteGet(OO_REDIRECTED_VECT), (short)OO_AbsoluteGet(OO_VECT_REDIR));
	global.AntiCrashInstalled=TRUE;
}

void DisableCrashProtection(void)
{//Restore all changed vectors back to original saved state
	SetExceptionVectors(OO_AbsoluteGet(OO_VECTORS), OO_AbsoluteGet(OO_OLD_VECTORS), (short)OO_AbsoluteGet(OO_VECT_SAVED));
	global.AntiCrashInstalled=FALSE;
}

void MakeExceptionVectorBackup(void)
{//because this func is exported, it does some extra error checking
	register BOOL isProtected=global.AntiCrashInstalled;
	
	if(isProtected)	{ DisableCrashProtection();	}	//Don't want to backup currently installed vectors	
	
	BackupExceptionVectors(OO_AbsoluteGet(OO_VECTORS), OO_AbsoluteGet(OO_OLD_VECTORS), (short)OO_AbsoluteGet(OO_VECT_SAVED));
	
	if(isProtected)	{ EnableCrashProtection();	}	//Re-enable crash protection if it was disabled
}

//restore the screen as best we can... without violating the contest rules...
//I would like to replace this routine with an array containing HSR v3.0
//(written by myself)
static void RestoreLCD(void)
{

	Access_AMS_Global_Variables;
	HANDLE h;
	
	if(OO_HasAttr((pFrame)HeapDeref(EV_currentApp), OO_APP_DEFAULT_MENU_HANDLE))
	{
		h=(const HANDLE)GetAppDefaultMenuHandle(EV_currentApp);
		if(h) MenuOn(h);
		//MenuUpdate(); could replace all of this...but its not documented
	}
	
	//i need a way to make all windows dirty, or a way to force all windows to be repainted FirstWindow (not documented) would come in handy
		
	ST_helpMsg("");
	ST_eraseHelp();

}

/*
static void RestoreLCD(void)
{//Binary of HSR v3.0
	asm(" .word 0x48e7,0xfffe,0x2878,0x00c8,0x206c,0x0124,0x4e90,0x3f3c,0x000a\n"
		" .word 0x206c,0x03ac,0x4e90,0x206c,0x038c,0x4e90,0x2f3c,0x0000,0x001e,0x3f3c\n"
		" .word 0x00ff,0x200c,0x0280,0x0040,0x0000,0x6612,0x206c,0x00bc,0x0c28,0x00ef\n"
		" .word 0x0002,0x6706,0x4878,0x56e6,0x6004,0x4878,0x5a2e,0x206c,0x09f0,0x4e90\n"
		" .word 0x2054,0x2050,0x0050,0x2000,0x4aa8,0x0022,0x2068,0x0022,0x66f2,0x4fef\n"
		" .word 0x000c,0x4cdf,0x7fff,0x4e75",106);//,0x4e71
}
*/

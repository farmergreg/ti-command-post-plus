/**************************************************
***	Project Title: Command Post (KFLASH)		***
***	Author: Greg Dietsche						***
***	Date:	07/23/2002							***
***	Description: An application designed for	***
*** use with the TI-89 and TI-92 Plus Graphing	***
*** calculators during the testing and			***
*** debugging phases of FLASH APPS and RAM      ***
*** programs									***
***************************************************/

#include <tiams.h>
#include "KFLASH.h"
#include "KFLASHr1.H"
#include "leakwatch.h"

static void LeakWatch_Event_Handler(pFrame self, PEvent e);
static BOOL LeakWatchAppCanDelete(AppID self);
static BOOL LeakWatchAppCanMove(AppID self);
static BOOL AppHasLeakWatch(AppID app);
static void InstallLeakWatch(AppID app);
static void UninstallLeakWatch(AppID app);
static void LeakWatchAll(void);
static DWORD VarTableSize(void);
static long CalcFolderSize(void);

FRAME(LeakWatchFrame, OO_SYSTEM_FRAME, 0, OO_APP_PROCESS_EVENT, 1)
	ATTR(OO_APP_PROCESS_EVENT, 		&LeakWatch_Event_Handler)	//0x0004
//	ATTR(OO_APP_CAN_DELETE,			&LeakWatchAppCanDelete)		//0x000C
//	ATTR(OO_APP_CAN_MOVE,			&LeakWatchAppCanMove)		//0x000D
ENDFRAME

void LeakWatchDialog(void)
{
	Access_AMS_Global_Variables;
	LEAK_DAT *d=&global.leak_dat;
	char *pupText;
	char buff[250];
	
	d->optList[1]=1;	//force currently selected app to be index #1
	
	TRY
		switch(Dialog(&dlgLeakWatch, -1, -1, NULL, d->optList))
		{
			case KB_ENTER:				
				if(strlen(pupText=PopupText(d->pupApps, d->optList[1])))
					switch(d->optList[0])
					{
						case LEAK_INSTALL:
							if(!strcmp(XR_stringPtr(XR_AllApps), pupText))
								LeakWatchAll();
							else
		 						InstallLeakWatch(OO_AppNameToACB((UCHAR *)pupText, TRUE));
		 					sprintf(buff, XR_stringPtr(XR_LeakWatchInstall), pupText);
		 					DlgNotice(XR_stringPtr(XR_LongAppName), buff); 
						break;
						
						case LEAK_UNINSTALL:
							if(!strcmp(XR_stringPtr(XR_AllApps), pupText))
								LeakWatchNone();
							else
								UninstallLeakWatch(OO_AppNameToACB((UCHAR *)pupText, TRUE));
							
							sprintf(buff, XR_stringPtr(XR_LeakWatchRemove), pupText);
		 					DlgNotice(XR_stringPtr(XR_LongAppName), buff);
						break;
					};			
			break;
				
			case DB_MEMFULL:			//handle low memory error
				EV_errorCode=ER_MEMORY;
				break;
		}
	ONERR
		EV_errorCode=errCode;
	ENDTRY
	
	HeapFreeIndir(&d->pupApps);
}

HANDLE pupLeakWatchApps(WORD index)
{
	Access_AMS_Global_Variables;
	LEAK_DAT *d=&global.leak_dat;
	HANDLE *h=&d->pupApps;
	AppID appid;
	
	HeapFreeIndir(h);
	*h=PopupNew(NULL, 0);
	
	for(appid=OO_firstACB; appid; appid=OO_NextACB(appid))
	{	
		switch(d->optList[0])
		{
			case LEAK_INSTALL:
				if(IsLeakWatchable(appid))
					PopupAddText(*h, -1,  (char *)GetAppName(appid), 0); 
			break;
			
			case LEAK_UNINSTALL:
				if(AppHasLeakWatch(appid))
					PopupAddText(*h, -1,  (char *)GetAppName(appid), 0); 					
			break;
		};
	}
	
	if(strlen(PopupText(*h, 2)))//if there is more than 1 item in the dynamic popup
		PopupAddText(*h, -1, XR_stringPtr(XR_AllApps), 0);
	
	return *h;	
}

static void LeakWatchAll(void)
{
	Access_AMS_Global_Variables;
	AppID appid;
	
	for(appid=OO_firstACB; appid; appid=OO_NextACB(appid))
	{	
		if(IsLeakWatchable(appid))
			InstallLeakWatch(appid); 					
	}	
}

void LeakWatchNone(void)
{
	Access_AMS_Global_Variables;
	AppID appid;
	
	for(appid=OO_firstACB; appid; appid=OO_NextACB(appid))
	{	
		if(AppHasLeakWatch(appid))
			UninstallLeakWatch(appid); 					
	}	

}

//this routine may throw a low memory error
static void InstallLeakWatch(AppID app)
{
	LEAK_DAT *d=&global.leak_dat;
	LEAK_NODE *node=&d->head;
	LEAK_NODE *previous;
	
	while(node->next)node=HeapDeref(node->next);	//find the last node
	
	previous=node;
	previous->next=HeapAllocThrow(sizeof(LEAK_NODE));
	node=HeapDeref(previous->next);
	
	node->app=app;
	node->next=H_NULL;
	
	if(!OO_InstallAppHook(app, (pFrame)&LeakWatchFrame, &node->frame))
	{
		HeapFreeIndir(&previous->next);
		ER_throw(ER_MEMORY);
	}
}

static void UninstallLeakWatch(AppID app)
{
	LEAK_DAT *d=&global.leak_dat;
	LEAK_NODE *node=&d->head;
	LEAK_NODE *previous=node;
	HANDLE notthewhales;
	
	do {
		if(app==node->app)break;
		previous=node;
	}while(node=node->next?HeapDeref(node->next):NULL);
	
	OO_UninstallAppHook(app, node->frame);	//unhook
	notthewhales=previous->next;
	previous->next=node->next;				//adjust linked list
	HeapFree(notthewhales);					//free this node
}

//returns true if a app has a leak watch frame installed
static BOOL AppHasLeakWatch(AppID app)
{
	LEAK_DAT *d=&global.leak_dat;
	LEAK_NODE *node=&d->head;

	while(node=node->next?HeapDeref(node->next):NULL) {
		if(app==node->app)
			return TRUE;
	}
	
	return FALSE;
}

BOOL LeakWatchAppsNotActive(void)
{
	Access_AMS_Global_Variables;
	LEAK_DAT *d=&global.leak_dat;
	LEAK_NODE *node=&d->head;

	while(node=node->next?HeapDeref(node->next):NULL) {
		if(EV_runningApp==node->app)		//use of Running App is important! Don't use Current App.
			return FALSE;
	}
	
	return TRUE;
}

//callback routine for dlgLeakWatch
DWORD cbLeakWatch(WORD DlgId, DWORD dValue)
{
	if(DlgId==0)
		return DB_REDRAW_AND_CONTINUE;
		
	return TRUE;
}

void export_LeakWatchBegin(void)
{
	LEAK_DAT *d=&global.leak_dat;
	
	d->start=HeapAvail();
	d->varstart=VarTableSize();
}

DWORD export_LeakWatchEnd(char *title)
{
	LEAK_DAT *d=&global.leak_dat;
	return LeakWatchEnd(title, d->start, d->varstart);
}

DWORD LeakWatchEnd(char *title, DWORD memtable, DWORD vartable)
{
	register DWORD deltamem=HeapAvail()-memtable;
	register DWORD deltavar=VarTableSize()-vartable;
	char buff[500];
	
	if(deltamem)	//only check memory for changes (variable table changes are ok)
	{
		sprintf(buff, OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LeakWatchStr), 
		memtable, HeapAvail(), deltamem,
		vartable, VarTableSize(), deltavar);
		DlgNotice(title, buff);
	}

	return deltamem;
}

static void LeakWatch_Event_Handler(pFrame self, PEvent e)
{
	Access_AMS_Global_Variables;
	LEAK_DAT *d=&global.leak_dat;
	pFrame super = OO_SuperFrame;
	char *appname=OO_GetAttr(self, OO_APP_NAME);
	char buff[500];
	
	switch (e->command)
	{
		case CM_START:
			d->internalStart=HeapAvail();
			d->internalVarStart=VarTableSize();
			if(super) AppProcessEvent(super, e);
			break;
			
		case CM_QUIT:
			if(super) AppProcessEvent(super, e);
			LeakWatchEnd((char *)appname, d->internalStart, d->internalVarStart);
		break;
		
		case CM_PACK:
			sprintf(buff,OO_AbsoluteGet(OO_FIRST_APP_STRING + XR_LeakPackInfo) , appname);
			DlgNotice(appname, buff);
			
		case CM_UNINSTALL:
			UninstallLeakWatch(((ACB*)HeapDeref(OO_AppNameToACB((UCHAR*)appname, TRUE)))->myID);
			if(super) AppProcessEvent(super, e);
		break;
		
		default:
			if(super) AppProcessEvent(super, e);		
	};
}

//calculate the size of the variables in the var-link
static DWORD VarTableSize(void)
{
	register SYM_ENTRY *sym;
	register DWORD result=0;
	//register unsigned short *len;
	//register long foldersize=CalcFolderSize();
	
	FolderOp(NULL, FL_ALL | FL_LOCK);
	
	sym=SymFindFirst(NULL, FO_RECURSE);
	
	while(sym)
	{
		//len=HeapDeref(sym->hVal);
	
		//if(!(sym->Flags & SF_FOLDER))	//don't count folders
		//{
		//see the HeapAlloc documentation for why...
			//result+= *len<7 ? 10 : *len + 4;		//minimum length is 8 bytes (allocated length is *len + 2 + 2) (i'm not sure where the second +2 (the handle?) comes in, but it is necessary to get the correct results
			//if(*len>6 && *len%2)result++;			//make length even
			if(!(sym->Flags & SF_EXTMEM))		//don't count archived variables	
				result+=HeapSize(sym->hVal)+2;
		//}
	//	else
	//	{//146 bytes on ams 2.05
			//result+=foldersize;
	//		result+=HeapSize(sym->hVal)+2;
	//	}
		
		sym=SymFindNext();
	}
	
	FolderOp(NULL, FL_ALL | FL_UNLOCK);
	
	return result;
}

/*
static long CalcFolderSize(void)
{//I have assumed nothing regarding folder size across AMS versions
//this code will determine how much ram a _NEW_ folder will occupy
//if there is enough free memory else a default value of 146 (bytes)
//will be returned (this is the value for AMS 2.05)

	Access_AMS_Global_Variables;
	EStackIndex oldtop=top_estack;
	static long size=0;
	static BOOL error=FALSE;
	WORD curfolder;
	
	if(size!=0 && !error)	//only recalculate if there was an error last time around
		return size;
		
	size=HeapAvail();
	error=FALSE;
	
	MO_currentOptions();
	curfolder=MO_option[MO_OPT_CURRENT_FOLDER];
	
	TRY
		push_quantum(END_TAG);				//for cmd_delfold
		TokenizeSymName((BYTE *)"zkflhtmp", TSF_PASS_ERRORS);
		cmd_newfold(top_estack);
		size-=HeapAvail();	//calculate the amount of ram used by the folder
		cmd_delfold(top_estack);
		
	ONERR	//assuming that the folder was not created
		error=TRUE;
		top_estack=oldtop;
		clear_error_context();
		return 146L;		//default to the value for AMS 2.05
		
	ENDTRY
	
//switch back to previous folder
	MO_currentOptions();
	MO_option[MO_OPT_CURRENT_FOLDER]=curfolder;
	MO_digestOptions(0);
	
	top_estack=oldtop;
	return size;
}
*/

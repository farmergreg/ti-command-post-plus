I have provided ErrorSim, a testing utility for your convience.
Please understand that the ErrorSim WILL crash your calculator. You WILL loose data, and there WILL be memory leaks.

If you don't want to use it, then don't.

Make sure that you have a backup of anything that is important to you on your calculator before using ErrorSim.

You assume full responsibility for any and all damage that may be caused by the errorsim utility when you run it on a calculator.

Using the ErrorSim is easy. Just run the program, and select the type of error that you would like to cause.
Please note that Command Post is not designed to handle every error situation that ErrorSim can create.
For more information regarding the errors that Command Post can handle, read the Command Post documentation.

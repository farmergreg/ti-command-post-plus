Thank-you for purchasing the Command Post Professional License!
If you have any questions, comments, concerns, or bug reports; feel free to email me
at greg@gregd.org.

Project Specific Notes:
	Command Post was original named KFLASH which reflected the initial concept which
	turned into the Command Post Project. KFLASH refers to the idea of KerNO running as
	a Flash Application among other things. Because of this, you may find scattered references
	to KFLASH in the source code. Most notably is the KFLASH.c and KFLASH.h files which contain
	code and #define declarations which directly relate to nearly every other piece of this project.
	The primary event loop is found in KFLASH.c .
	
**********
How To Build Command Post
This has been tested with TI-Flash Studio (TIFS) Version 1.1 Build 37
I cannot guarantee that you will be able to compile Command Post using any other version of TIFS!

1. Run clean.bat
2. Open Either KFLASH89.FSP or KFLASH92.FSP with TI-Flash Studio depending on your target calculator
3. Change the build type to 'Release Mode' in TI-Flash Studio (this is *absolutely* necessary)
	*some parts of Command Post will not be compiled correctly in *DEBUG* mode
4. Build the project
5. Problems? close TI-Flash Studio, run clean.bat, reopen TI-Flash Studio

**********
	If you run into problems, close TI Flash Studio, and run clean.bat; 97% of the time, 
	this will eliminate TIFS strangeness :) Otherwise, email me (greg@gregd.org), 
	and I will help you.
**********

	You are allowed to use the Command Post source code for yourself (or business) only. The source
	has been included in the Professional License to allow individuals and/or businesses modify
	Command Post to better suit their needs. You may not distribute or sell altered versions 
	of Command Post or its source code without my written consent.

This source code contains a few minor bug fixes that are not found in the standard 1.0 release:
	*Corrected the spelling of foreward (was mispelled as foreword)
	*When 'F1->Set Defaults' is used, the Hex Editor will revert to the 'default' byte width
	
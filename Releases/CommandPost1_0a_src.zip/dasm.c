/**************************************************
***	Project Title: Command Post (KFLASH)		***
***	Author: Greg Dietsche						***
***	Date:	07/23/2002							***
***	Description: An application designed for	***
*** use with the TI-89 and TI-92 Plus Graphing	***
*** calculators during the testing and			***
*** debugging phases of FLASH APPS and RAM      ***
*** programs									***
***************************************************/

#include "tiams.h"
#include "undoc.h"
#include "kflash.h"
#include "dasm.h"

#ifndef NO_DASM

#include "asmcode.h"		//temporary sample asm code for testing only!!

//macros for individual nibble access (read left to right)
#define NIBBLE_4(n)(n&0x000f)
#define NIBBLE_3(n)((n&0x00f0)>>4)
#define NIBBLE_2(n)((n&0x0f00)>>8)
#define NIBBLE_1(n)((n&0xf000)>>12)

//For Easy EA mode decoding in disassemble_one
#define make_double_ea(sz) make_ea(pc, &count, EA_SRC_AND_DEST, sz)
#define make_single_ea(sz) make_ea(pc, &count, EA_SRC_ONLY, sz)

void quickie(void)
{
	Access_AMS_Global_Variables;
	short i;
	unsigned short*next;
	DASM_DAT *dat;
	char buff[20];
	short oldwinflags=appW.Flags;

	#ifdef _89
		WinBeginPaint(&appW);
		WinFont(&appW, F_4x6);
	#endif
	
	appW.Flags|=WF_TTY;
	WinClr(FirstWindow);
	WinStrXYWrap(&appW,0,0,"68kDasm 10 Line Test\r",A_NORMAL);

	if(DlgMessage("68k DASM Demo","Press enter to view preset or cancel to dasm current hex view",PDB_OK,PDB_CANCEL)==KB_ENTER)
		next=asmcode;
	else
		next=(unsigned short*)global.hex_dat.top;

	for(i=0;i<10;i++)
	{
		sprintf(buff,"$%lx:",next);
		dat=disassemble_one(next);
		WinStr(&appW,buff);
		WinStr(&appW,dat->text);
		next=dat->pc;
		WinStr(&appW,"\r");
	}
    
    ST_helpMsg("Press any key to continue...");	//NO, NOT THAT KEY!!
    ngetchx();
    ST_eraseHelp();
	
	#ifdef _89
		WinEndPaint(&appW);
	#endif
	
	appW.Flags=oldwinflags;
	appW.Flags|=WF_DIRTY;
}

DASM_DAT *disassemble_one(unsigned short *pc)
{
	const char   SIZES[3]		  ={'b','w','l'};
	const char * const TEST_CC[8] ={"t" ,"f", "hi","ls","cc","cs","ne","eq"};
	const char * const TEST_BCC[8]={"vc","vs","pl","mi","ge","lt","gt","le"};
	const char * const ALT_BCC[2] ={"ra","sr"};	//bra, bsr
	static DASM_DAT buff;
	char *txt;
	unsigned short count=0;	//number of bytes to increment the pc after a make_ea call
	//unsigned short ea_src=*pc&0x3F;	//last 6 bits of first word of the instruction
	//unsigned short ea_dest=(*pc&0xFC0)>>6;	//second to last set of 6 bits of the first word of the instruction
	unsigned short word=*pc;
	unsigned short n1=NIBBLE_1(word);
	unsigned short n2=NIBBLE_2(word);
	unsigned short n3=NIBBLE_3(word);
	unsigned short n4=NIBBLE_4(word);
	
	txt=buff.text;
	*txt++=' ';
	buff.pc=pc;
	
	switch(n1)
	{
		case  0:	//%0000 Bit Manipulation/MOVEP/Immediate
			sprintf(txt,"dc.w $%x",word);
			break;
			
		case  1:	//%0001 Move Byte
			sprintf(txt,"move.b %s", make_double_ea(IMM_BYTE));
			break;
		case  2:	//%0010 Move Long
			if((word&0x1c0)==0x40)
				sprintf(txt,"movea.l %s", make_double_ea(IMM_LONG));
			else
				sprintf(txt,"move.l %s", make_double_ea(IMM_LONG));
			break;
			
		case  3:	//%0011 Move Word
			if((word&0x1c0)==0x40)
				sprintf(txt,"movea.w %s", make_double_ea(IMM_WORD));
			else
				sprintf(txt,"move.w %s", make_double_ea(IMM_WORD));
			break;
			
		case  4:	//%0100 Miscellaneous
			if((word&0xFFF0)==0x4e40){ sprintf(txt,"trap #%d",(unsigned short)word&0xF); break; }
			if((word&0xFFF0)==0x4E60)
			{
				if(n4&0x8)
				{
					sprintf(txt,"move.l a%d,usp",n4&0x7);
					break;
				}
				else
				{
					sprintf(txt,"move.l usp,a%d",n4&0x7);
					break;
				}
			}
			
			switch(word&0xFFC0)
			{
				case 0x44c0:
					sprintf(txt,"move.w %s,ccr",make_single_ea(IMM_WORD));
					break;
				
				case 0x40C0:
					sprintf(txt,"move.w sr,%s",make_single_ea(IMM_WORD));
					break;
				
				case 0x46C0:
					sprintf(txt,"move.w %s,sr",make_single_ea(IMM_WORD));
					break; 
					
				default:				
					switch(word)
					{//handle op codes with no operands
					
						case 0x4E70:	//RESET
							strcpy(txt,"reset");
							break;
						case 0x4E71:	//NOP
							strcpy(txt,"nop");
							break;
						case 0x4E72:	//STOP
							sprintf(txt, "stop #$%x",pc[1]);
							count=1;
							break;
						case 0x4E73:	//RTE
							strcpy(txt,"rte");
							break;
						case 0x4E75:	//RTS
							strcpy(txt,"rts");
							break;
						case 0x4E77:	//RTR
							strcpy(txt,"rtr");
							break;
						case 0x4AFC:	//ILLEGAL
							strcpy(txt,"illegal");
							break;
		
						default:
							sprintf(txt,"dc.w $%x",word);
							break;	
					};
			};//word&0xFFC0
			break;
			
		case  5:	//%0101 ADDQ/SUBQ/Scc/DBcc
		case  6:	//%0110 Bcc/BSR
			{
				signed short displacement=(char)pc[0];
				char displacement_type='b';

				if(!displacement)
				{
					//16 bit displacement field present
					displacement=(signed short)pc[1];
					displacement_type='w';
					count=1;
				}

				displacement=displacement>>1;	///=2;
				displacement++;
				sprintf(txt,"b%s.%c $%lx",n2>2?TEST_BCC[n2&0x7]:ALT_BCC[n2],displacement_type,(unsigned long)&pc[displacement]);
				
			}
		
			break;
			
		case  7:	//%0111 MOVEQ
			sprintf(txt,"moveq.l #$%x,d%d",word&0xff, n2>>1);
			break;
			
		case  8:	//%1000 OR/DIV/SBCD
		case  9:	//%1001 SUB/SUBX
		{//scope brackets for variable declaration within case statement
			short size=(n3&0xc)>>2;
			short reg=n2>>1;
			
			switch(n2&1)
			{
				case 1:
					switch(n3&3)
					{
						case 0:
							switch(n4&8)
							{
								case 8:
									sprintf(txt,"subx.%c -(a%d),-(a%d)",SIZES[size], n4&7, reg);
									break;
								case 0:
									sprintf(txt,"subx.%c d%d,d%d",SIZES[size], n4&7, reg);
									break;	
							};
							break;
						default:
							sprintf(txt,"sub.%c d%d,%s", SIZES[size], reg, make_single_ea(size));
							break;
					}
					break;
				case 0:
					sprintf(txt,"sub.%c %s,d%d", SIZES[size], make_single_ea(size), reg);
					break;
			};
		}//END: scope brackets for variable declaration
			break;
			
		case 10:	//%1010 (Unassigned)
			sprintf(txt,"dc.w $%x ;Line $A Exception",word);
			break;
			
		case 11:	//%1011 CMP/EOR
		case 12:	//%1100 AND/MUL/ABCD/EXG
		case 13:	//%1101 ADD/ADDX
		case 14:	//%1110 Shift/Rotate
			sprintf(txt,"dc.w $%x",word);
			break;
		case 15:	//%1111 (Unassigned)
			sprintf(txt,"dc.w $%x ;Line $F Exception",word);
			break;
			
		default:	//handle unknown op code as data
			sprintf(txt,"dc.w $%x",word);
			break;
	}

	buff.pc+=(count+1);
	return &buff;
}

/*
static char* make_hex_str(unsigned long val)
{
	static char str[20];

	val &= 0xffffffff;

	if(val == 0x80000000)
		sprintf(str, "-$80000000");
	else if(val & 0x80000000)
		sprintf(str, "-$%x", (0-val) & 0x7fffffff);
	else
		sprintf(str, "$%x", val & 0x7fffffff);

	return str;
}
*/

//pc=current program counter
//size=should be initialized to zero normally, and will contain the offset to the next instruction
//		upon return	
//which_ea=EA_SRC_ONLY if only a src ea is present; if src and dest ea are present, pass EA_SRC_AND_DEST
//imm_bytes_wide=IMM_BYTE, IMM_WORD, or IMM_LONG depending on the instruction size (b,w,l)
char *make_ea(unsigned short *pc, unsigned short *size, short which_ea, short imm_bytes_wide)
{
	const char * const EA_MODE[5] ={"d%d",				//Dn			0
									"a%d",				//An			1
									"(a%d)",			//(An)			2
									"(a%d)+",			//(An)+			3
									"-(a%d)",			//-(An)			4
									};
	static char buff[50];
	char *txt;
	unsigned short mode;
	unsigned short reg;
	unsigned short tmp_size=*size + 1;
	static short self_call=FALSE;
	
	short ex_reg,ex_reg_displacement;	//used for d8(an,xn) and similar
	char ex_reg_type, ex_reg_size;		//used for d8(an,xn) and similar
    
    if(self_call)
    {
    	self_call=FALSE;
    	txt=&buff[strlen(buff)];
    	*txt++=',';
    	
    	reg=(*pc&0xE00)>>9;
		mode=(*pc&0x1C0)>>6;
    }
    else
    {
    	txt=buff;
    	
    	mode=(*pc&0x38)>>3;
		reg=*pc&0x7;
    }

	switch(mode==7?mode+reg:mode)
	{
		case 0:case 1:case 2:case 3:case 4:
			sprintf(txt,EA_MODE[mode],reg);
			break;
		case 5:
			sprintf(txt,"$%x(a%d)",pc[tmp_size],reg);
			(*size)++;
			break;
		case 6:
			ex_reg_displacement=pc[tmp_size]&0xff;
			ex_reg_type=pc[tmp_size]&0x8000?'a':'d';
			ex_reg=(pc[tmp_size]&0x7000)>>12;
			ex_reg_size=pc[tmp_size]&0x800?'l':'w';
			sprintf(txt,"$%x(a%d,%c%d.%c)", ex_reg_displacement, reg, ex_reg_type, ex_reg, ex_reg_size);
			(*size)++;
			break;
		case 7:	//.w
			sprintf(txt,"($%x).w",pc[tmp_size]);
			(*size)++;
			break;
		case 8:	//.l
			sprintf(txt,"($%lx).l",*(unsigned long*)&pc[tmp_size]);
			(*size)+=2;
			break;
		case 9:
			sprintf(txt,"$%x(pc)",pc[tmp_size]);
			(*size)++;
			break;
		case 10:
			ex_reg_displacement=pc[tmp_size]&0xff;
			ex_reg_type=pc[tmp_size]&0x8000?'a':'d';
			ex_reg=(pc[tmp_size]&0x7000)>>12;
			ex_reg_size=pc[tmp_size]&0x800?'l':'w';
			sprintf(txt,"$%x(pc,%c%d.%c)", ex_reg_displacement, ex_reg_type, ex_reg, ex_reg_size);
			(*size)++;
			break;
		case 11:
			switch(imm_bytes_wide)
			{
				case 0:case 1:	//immediate byte or word
					sprintf(txt,"#$%x",pc[tmp_size]);
					(*size)++;
					break;
				case 2:			//immediate long
					sprintf(txt,"#$%lx",*(unsigned long*)&pc[tmp_size]);
					(*size)+=2;
					break;
				default:
					sprintf(txt,"ea error imm_bytes_wide=%d",imm_bytes_wide);
					break;
			}
			break;
		default:
			sprintf(txt,"ea error: mode+reg=0x%x",mode);
			break;
	};
    
    if(which_ea)
    {
    	self_call=TRUE;
    	make_ea(pc,size,0, imm_bytes_wide);
    }

	return txt;
}
		
/*
ROM_CALL3 macro
 move.l \1*4(a4),a0
 jsr (a0)
 endm
*/ 
 
 /*
unsigned short bsearch(unsigned short *array, unsigned short key, unsigned short last)
{
	unsigned short i;
	unsigned short mid;
	unsigned short first=0;
	
	while(first <= last)
	{
		mid=(first+last)>>1;
		
		if (key>array[mid])
			first=mid+1;
		else if (key<array[mid])
			last=mid-1;
		else
			return mid;
	}
		
	return NULL;
}	

*/


#endif //#ifndef NO_DASM


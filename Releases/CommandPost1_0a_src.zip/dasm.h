/**************************************************
***	Project Title: Command Post (KFLASH)		***
***	Author: Greg Dietsche						***
***	Date:	07/23/2002							***
***	Description: An application designed for	***
*** use with the TI-89 and TI-92 Plus Graphing	***
*** calculators during the testing and			***
*** debugging phases of FLASH APPS and RAM      ***
*** programs									***
***************************************************/
#ifndef _DASM_H_
#define _DASM_H_

enum {EA_SRC_ONLY=0,EA_SRC_AND_DEST=1};
enum {IMM_BYTE=0,IMM_WORD=1,IMM_LONG=2};

typedef struct{
	unsigned short *pc;		//the next address to be disassembled
	char text[100];			//human readable disassembly code ie move.l a0,-(sp)
}DASM_DAT;

	DASM_DAT *disassemble_one(unsigned short *pc);
	char *make_ea(unsigned short *pc, unsigned short *size, short which_ea, short imm_bytes_wide);
 	void quickie(void);
 	
#endif

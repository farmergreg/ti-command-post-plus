//This file implements certain easter eggs found within Command Post
//other eggs may be found elsewhere in the source code
//look for NO_EASTER_EGGS compile time conditionals
#ifndef __RED_PILL_NEO_
#define __RED_PILL_NEO_ 

#ifndef NO_EASTER_EGGS

void RedPillNeo(void);
void GreenLightGo(void);

#endif	//#ifndef NO_EASTER_EGGS
#endif	//#ifndef __RED_PILL_NEO_

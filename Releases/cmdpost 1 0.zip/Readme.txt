   ______                                          __   ____             __ 
  / ____/___  ____ ___  ____ ___  ____ _____  ____/ /  / __ \____  _____/ /_
 / /   / __ \/ __ `__ \/ __ `__ \/ __ `/ __ \/ __  /  / /_/ / __ \/ ___/ __/
/ /___/ /_/ / / / / / / / / / / / /_/ / / / / /_/ /  / ____/ /_/ (__  ) /_  
\____/\____/_/ /_/ /_/_/ /_/ /_/\__,_/_/ /_/\__,_/  /_/    \____/____/\__/ 


Command Post 1.0 (February 15th, 2003)
by Greg Dietsche

Thank you for downloading Command Post for the TI-89, TI-92 Plus, and V200.

License Agreement:					www.detachedsolutions.com/cmdpost/license.php
General documentation is available online at:	www.detachedsolutions.com/cmdpost/
The Quick Start Guide:					www.detachedsolutions.com/cmdpost/quickstart.php
Installation Help:	 				www.detachedsolutions.com/cmdpost/install.php

Please read the online documentation and user manual before using Command Post.
Any questions or comments may be sent to: cmdpost@detachedsolutions.com

Command Post is licensed, not sold. Those using Command Post to aid in the development of applications which will not be sold or licensed for a fee are not required to pay a licensing fee for Command Post; this is referred to as the Amateur License. All other usages of Command Post are subject to a licensing fee of $15.00USD per copy installed on a handheld or emulator; this is referred to as the professional license. Those purchasing the professional license are entitled to receive a copy of the Command Post source code. The Command Post source code may not be redistributed, sold, or released under any other license. Purchasers of the professional license will also receive priority support via Email.

Detached Solutions takes no responsibility for any adverse effect that this software could cause to your machine or the data on it: backup important data before using Command Post. Command Post is protected by copyright laws and international copyright treaties, as well as other intellectual property laws and treaties. Command Post is licensed, not sold.

Written permission must be obtained before distribution of this program, through any online or offline methods. 

Copyright (c) 2002, 2003 -- Detached Solutions (www.detachedsolutions.com)

   ______                                          __   ____             __ 
  / ____/___  ____ ___  ____ ___  ____ _____  ____/ /  / __ \____  _____/ /_
 / /   / __ \/ __ `__ \/ __ `__ \/ __ `/ __ \/ __  /  / /_/ / __ \/ ___/ __/
/ /___/ /_/ / / / / / / / / / / / /_/ / / / / /_/ /  / ____/ /_/ (__  ) /_  
\____/\____/_/ /_/ /_/_/ /_/ /_/\__,_/_/ /_/\__,_/  /_/    \____/____/\__/ plus!


Command Post Plus (December 28nd, 2003)
by Greg Dietsche

Thank you for downloading Command Post for the TI-89, TI-92 Plus, and V200.

Command Post Plus is a special suite of tools which is designed to help C and ASM programmers debug
and test their programs before public release. For more information and up-to-date documentation,
please visit the following webpages:

General documentation is available online at:		www.detachedsolutions.com/cmdpost/
The Quick Start Guide:					www.detachedsolutions.com/cmdpost/quickstart.htm
Installation Help:	 				www.detachedsolutions.com/cmdpost/install.htm
Online Discussion Forum:				www.detachedsolutions.com/forum/viewforum.php?f=17

Please read the online documentation and user manual before using Command Post.
Any questions or comments may be sent to: cmdpost@detachedsolutions.com


Written permission must be obtained in order to distribute this program. 

Copyright (c) 2002, 2003 -- Detached Solutions (www.detachedsolutions.com)


For best results, view this file in Notepad with wordwrap turned off.
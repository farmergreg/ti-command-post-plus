Send the MemDat and RomCalls database to your calculator (they can go in any folder as long as they keep their original name). They will allow Command Post Plus to identify rom calls when disassembling and allow Command Post Plus to identify absolute memory addresses. Best results are obtained when these databases are archived!


Full source code for building your own custom databases are found in the respective folders. If you make any additions or corrections that would beneifit the public, please email the changes to cmdpost@detachedsolutions.com, and we will update the databases in the Command Post Plus distribution.

For more information about these databases, see http://www.detachedsolutions.com/cmdpost/
